<?php
session_start();
$con = mysqli_connect('localhost','id16775937_routefinder','X*aNYF7]kkp~XR44');
$db = mysqli_select_db($con,'id16775937_routefinder_db');
?>