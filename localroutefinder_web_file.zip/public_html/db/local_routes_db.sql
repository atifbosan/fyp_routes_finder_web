-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 27, 2021 at 10:00 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `local_routes_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_announcement`
--

CREATE TABLE `tbl_announcement` (
  `announcement_id` int(11) NOT NULL,
  `announcement_title` varchar(255) DEFAULT NULL,
  `announcement_description` text DEFAULT NULL,
  `announcement_for` enum('D','U','BDU') NOT NULL DEFAULT 'BDU',
  `announcement_status` enum('A','B') NOT NULL DEFAULT 'A',
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_announcement`
--

INSERT INTO `tbl_announcement` (`announcement_id`, `announcement_title`, `announcement_description`, `announcement_for`, `announcement_status`, `createdBy`, `createdDate`, `updatedBy`, `updatedDate`) VALUES
(2, 'Dummy', 'This is Dummy Data', 'D', 'A', 1, '2021-04-27 09:24:33', NULL, NULL),
(3, 'Announcement for Driver', 'This is testing data', 'D', 'A', 1, '2021-04-27 09:38:57', NULL, NULL),
(4, 'Announcement for User', 'This is again testing data', 'U', 'A', 1, '2021-04-27 09:40:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cities`
--

CREATE TABLE `tbl_cities` (
  `id` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `city_ascii` varchar(255) NOT NULL,
  `lat` varchar(255) NOT NULL,
  `lng` varchar(255) NOT NULL,
  `country` varchar(55) NOT NULL,
  `iso2` varchar(255) NOT NULL,
  `iso3` varchar(255) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `capital` varchar(255) NOT NULL,
  `population` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cities`
--

INSERT INTO `tbl_cities` (`id`, `city`, `city_ascii`, `lat`, `lng`, `country`, `iso2`, `iso3`, `admin_name`, `capital`, `population`) VALUES
(2, 'Karachi', 'Karachi', '24.87', '66.99', 'Pakistan', 'PK', 'PAK', 'Sindh', 'admin', '12130000'),
(3, 'Gilgit', 'Gilgit', '35.9171', '74.3', 'Pakistan', 'PK', 'PAK', 'Gilgit-Baltistan', 'minor', '216760'),
(4, 'Chaman', 'Chaman', '30.925', '66.4463', 'Pakistan', 'PK', 'PAK', 'Balochist?n', '', '88568'),
(5, 'Turbat', 'Turbat', '25.9918', '63.0718', 'Pakistan', 'PK', 'PAK', 'Balochist?n', '', '147791'),
(6, 'Islamabad', 'Islamabad', '33.7', '73.1666', 'Pakistan', 'PK', 'PAK', 'Isl?m?b?d', 'primary', '780000'),
(7, 'Zhob', 'Zhob', '31.349', '69.4386', 'Pakistan', 'PK', 'PAK', 'Balochist?n', 'minor', '88356'),
(8, 'Quetta', 'Quetta', '30.22', '67.025', 'Pakistan', 'PK', 'PAK', 'Balochist?n', 'admin', '768000'),
(9, 'Hyderabad', 'Hyderabad', '25.38', '68.375', 'Pakistan', 'PK', 'PAK', 'Sindh', '', '1459000'),
(10, 'Mardan', 'Mardan', '34.2', '72.04', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '300424'),
(11, 'Saidu', 'Saidu', '34.75', '72.35', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '1860310'),
(12, 'Jhang', 'Jhang', '31.2804', '72.325', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '341210'),
(13, 'Kasur', 'Kasur', '31.1254', '74.455', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '290643'),
(14, 'Lahore', 'Lahore', '31.56', '74.35', 'Pakistan', 'PK', 'PAK', 'Punjab', 'admin', '6577000'),
(15, 'Nawabshah', 'Nawabshah', '26.2454', '68.4', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '229504'),
(16, 'Chiniot', 'Chiniot', '31.72', '72.98', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '201781'),
(17, 'Bannu', 'Bannu', '32.989', '70.5986', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '622419'),
(18, 'Sadiqabad', 'Sadiqabad', '28.3006', '70.1302', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '189876'),
(19, 'Sukkur', 'Sukkur', '27.7136', '68.8486', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '417767'),
(20, 'Peshawar', 'Peshawar', '34.005', '71.535', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'admin', '1303000'),
(21, 'Bahawalpur', 'Bahawalpur', '29.39', '71.675', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '552607'),
(22, 'Sargodha', 'Sargodha', '32.0854', '72.675', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '542603'),
(23, 'Dera Ismail Khan', 'Dera Ismail Khan', '31.829', '70.8986', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '101616'),
(24, 'Kundian', 'Kundian', '32.4522', '71.4718', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '35406'),
(25, 'Gwadar', 'Gwadar', '25.139', '62.3286', 'Pakistan', 'PK', 'PAK', 'Balochist?n', 'minor', '51901'),
(26, 'Parachinar', 'Parachinar', '33.8992', '70.1008', 'Pakistan', 'PK', 'PAK', 'Federally Administered Tribal Areas', '', '55685'),
(27, 'Larkana', 'Larkana', '27.5618', '68.2068', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '364033'),
(28, 'Kohat', 'Kohat', '33.6027', '71.4327', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '343027'),
(29, 'Rahim Yar Khan', 'Rahim Yar Khan', '28.4202', '70.2952', 'Pakistan', 'PK', 'PAK', 'Punjab', '', '353203'),
(30, 'Mirput Khas', 'Mirput Khas', '25.5318', '69.0118', 'Pakistan', 'PK', 'PAK', 'Sindh', 'minor', '356435'),
(31, 'Dera Ghazi Khan', 'Dera Ghazi Khan', '30.0604', '70.6351', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '236093'),
(32, 'Gujranwala', 'Gujranwala', '32.1604', '74.185', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '1513000'),
(33, 'Rawalpindi', 'Rawalpindi', '33.6', '73.04', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '1858000'),
(34, 'Gujrat', 'Gujrat', '32.58', '74.08', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '301506'),
(35, 'Sialkote', 'Sialkote', '32.52', '74.56', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '477396'),
(36, 'Mansehra', 'Mansehra', '34.3418', '73.1968', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '66486'),
(37, 'Abbottabad', 'Abbottabad', '34.1495', '73.1995', 'Pakistan', 'PK', 'PAK', 'Khyber Pakhtunkhwa', 'minor', '1183647'),
(38, 'Multan', 'Multan', '30.2', '71.455', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '1522000'),
(39, 'Sheikhu Pura', 'Sheikhu Pura', '31.72', '73.99', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '361303'),
(40, 'Sahiwal', 'Sahiwal', '30.6717', '73.1118', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '235695'),
(41, 'Okara', 'Okara', '30.8104', '73.45', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '223648'),
(42, 'Faisalabad', 'Faisalabad', '31.41', '73.11', 'Pakistan', 'PK', 'PAK', 'Punjab', 'minor', '2617000');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notifications`
--

CREATE TABLE `tbl_notifications` (
  `noti_id` int(11) NOT NULL,
  `noti_title` varchar(255) DEFAULT NULL,
  `noti_type` enum('DP','UP','A') DEFAULT NULL,
  `noti_for` enum('D','U','A') DEFAULT NULL,
  `noti_fk_id` int(11) DEFAULT NULL,
  `noti_forUserID` int(11) DEFAULT NULL,
  `noti_status` enum('0','1') DEFAULT '0',
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_routes`
--

CREATE TABLE `tbl_routes` (
  `route_id` int(11) NOT NULL,
  `route_title` varchar(255) DEFAULT NULL,
  `route_status` enum('A','B') NOT NULL DEFAULT 'A',
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_routes`
--

INSERT INTO `tbl_routes` (`route_id`, `route_title`, `route_status`, `createdBy`, `createdDate`, `updatedBy`, `updatedDate`) VALUES
(1, 'Saddar to Faizabad', 'A', 1, '2021-04-23 11:00:59', 1, '2021-04-23 11:06:04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(11) NOT NULL,
  `user_fullName` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `user_cnic` varchar(13) DEFAULT NULL,
  `user_contactNo` varchar(100) DEFAULT NULL,
  `user_address` text DEFAULT NULL,
  `user_cityID` int(11) DEFAULT NULL,
  `user_lat` decimal(16,6) DEFAULT NULL,
  `user_lng` decimal(16,6) DEFAULT NULL,
  `user_gender` enum('M','F') NOT NULL DEFAULT 'M',
  `user_type` enum('SA','D','U') NOT NULL DEFAULT 'U',
  `user_status` enum('P','R','A','B') NOT NULL DEFAULT 'P',
  `user_profileImage` varchar(255) DEFAULT NULL,
  `user_routeID` int(11) DEFAULT NULL,
  `user_vehicleID` int(11) DEFAULT NULL,
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `user_fullName`, `user_email`, `user_password`, `user_cnic`, `user_contactNo`, `user_address`, `user_cityID`, `user_lat`, `user_lng`, `user_gender`, `user_type`, `user_status`, `user_profileImage`, `user_routeID`, `user_vehicleID`, `createdBy`, `createdDate`, `updatedBy`, `updatedDate`) VALUES
(1, 'Super Admin', 'admin@admin.com', 'c3284d0f94606de1fd2af172aba15bf3', '3740518315667', '0332-0569001', 'Rawalpindi', 33, NULL, NULL, 'M', 'SA', 'A', NULL, NULL, NULL, 0, '2021-04-21 00:53:58', NULL, NULL),
(2, 'Shahbaz', 'shahbaz@gmail.com', '1231', '1234567891231', '12311231', 'Rawalpindi', 33, NULL, NULL, 'M', 'D', 'A', NULL, 1, 1, 0, '2021-04-01 00:00:00', 1, '2021-04-26 10:09:36'),
(3, 'Ali', 'ali@gmail.com', '1111', '123456733231', '121212', 'Rawalpindi', 33, NULL, NULL, 'M', 'U', 'B', NULL, 1, 1, 0, '2021-04-01 00:00:00', 1, '2021-04-27 09:55:13'),
(4, 'Usman', 'usma@gmail.com', '1111', '1234567313231', '12121211', 'Rawalpindi', 33, NULL, NULL, 'M', 'U', 'A', NULL, 1, 1, 0, '2021-04-01 00:00:00', 1, '2021-04-27 09:55:13');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicles`
--

CREATE TABLE `tbl_vehicles` (
  `vehicle_id` int(11) NOT NULL,
  `vehicle_title` varchar(255) DEFAULT NULL,
  `vehicle_status` enum('A','B') NOT NULL DEFAULT 'A',
  `createdBy` int(11) DEFAULT NULL,
  `createdDate` datetime DEFAULT NULL,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDate` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_vehicles`
--

INSERT INTO `tbl_vehicles` (`vehicle_id`, `vehicle_title`, `vehicle_status`, `createdBy`, `createdDate`, `updatedBy`, `updatedDate`) VALUES
(1, 'Honda', 'A', 1, '2021-04-25 08:18:37', NULL, NULL),
(3, 'Rikhshaw', 'A', 1, '2021-04-25 08:42:06', NULL, NULL),
(4, 'Motorbike', 'A', 1, '2021-04-25 08:57:03', 1, '2021-04-25 08:59:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_notifications`
--
ALTER TABLE `tbl_notifications`
  ADD PRIMARY KEY (`noti_id`);

--
-- Indexes for table `tbl_routes`
--
ALTER TABLE `tbl_routes`
  ADD PRIMARY KEY (`route_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `tbl_vehicles`
--
ALTER TABLE `tbl_vehicles`
  ADD PRIMARY KEY (`vehicle_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_cities`
--
ALTER TABLE `tbl_cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `tbl_notifications`
--
ALTER TABLE `tbl_notifications`
  MODIFY `noti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_routes`
--
ALTER TABLE `tbl_routes`
  MODIFY `route_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_vehicles`
--
ALTER TABLE `tbl_vehicles`
  MODIFY `vehicle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
