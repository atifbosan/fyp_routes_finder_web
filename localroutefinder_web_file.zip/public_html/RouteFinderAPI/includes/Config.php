<?php
//define('DB_NAME', 'id16775937_routefinder_db');
//define('DB_USER', 'id16775937_routefinder');
//define('DB_PASSWORD', 'X*aNYF7]kkp~XR44');
//define('DB_HOST', 'localhost');
