<?php

class DbConnect
{

    private $con;

    public function connect()
    {
        include 'Config.php';
        $this->con = new mysqli('localhost', 'id16775937_routefinder', 'X*aNYF7]kkp~XR44', 'id16775937_routefinder_db');
        if (mysqli_connect_errno()) {
            echo "failed to connect database" . mysqli_connect_errno();
        }

        return $this->con;
    }
}
